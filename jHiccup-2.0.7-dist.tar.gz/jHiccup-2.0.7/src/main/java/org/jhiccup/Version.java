/**
 * Written by Gil Tene of Azul Systems, and released to the public domain,
 * as explained at http://creativecommons.org/publicdomain/zero/1.0/
 *
 * @author Gil Tene
 */

package org.jhiccup;

public final class Version {
    public static final String version="2.0.7";
    public static final String build_time="2017-02-10T20:12:56Z";
}
